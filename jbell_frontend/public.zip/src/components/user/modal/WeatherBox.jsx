import React, { useEffect, useState } from "react";
import { api } from "@/utils/axiosConfig";

const WeatherBox = () => {
  const weatherKey = import.meta.env.VITE_API_WEATHER_KEY;
  const [weather, setWeather] = useState(null);
  const [address, setAddress] = useState(null);
  const [error, setError] = useState(null);

  const fetchFallbackWeather = async () => {
    try {
      const response = await api.external("/weather-api", {
        params: {
          lat: 35.8204,
          lon: 127.1087,
          appid: weatherKey,
          units: "metric",
          lang: "kr",
        },
      });
      setWeather(response.data);
      setAddress("전북특별자치도");
    } catch (e) {
      setError("날씨 정보를 불러오지 못했어요 😢");
    }
  };

  useEffect(() => {
    if (!navigator.geolocation) {
      setError("이 브라우저는 위치 정보를 지원하지 않아요 😢");
      fetchFallbackWeather();
      return;
    }

    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        const { latitude, longitude } = coords;

        api.external("/weather-api", {
          params: {
            lat: latitude,
            lon: longitude,
            appid: weatherKey,
            units: "metric",
            lang: "kr",
          },
        })
          .then((res) => setWeather(res.data))
          .catch(() => setError("날씨 정보를 불러오지 못했어요 😢"));

        if (window.kakao?.maps?.services) {
          const geocoder = new window.kakao.maps.services.Geocoder();
          geocoder.coord2Address(longitude, latitude, (result, status) => {
            if (status === window.kakao.maps.services.Status.OK) {
              setAddress(
                result[0].road_address?.address_name ||
                result[0].address.address_name
              );
            } else {
              setAddress("위치 확인 불가");
            }
          });
        } else {
          setAddress("위치 정보 없음");
        }
      },
      () => {
        fetchFallbackWeather();
      },
      {
        timeout: 5000,
        maximumAge: 300000,
      }
    );
  }, [weatherKey]);

  if (error) return <div className="h-full flex items-center justify-center text-white text-detail-m">{error}</div>;
  if (!weather) return <div className="h-full flex items-center justify-center text-white text-detail-m animate-pulse">날씨 확인 중...</div>;

  const details = [
    { label: "체감온도", value: `${Math.round(weather.main.feels_like)}°` },
    { label: "습도", value: `${weather.main.humidity}%` },
    { label: "풍속", value: `${weather.wind.speed}m/s` },
    { label: "구름", value: `${weather.clouds.all}%` },
  ];

  return (
    <div className="relative h-full flex flex-col justify-between">
      {/* 📍 위치 배지: 모바일에서 더 눈에 띄게 크기와 패딩 조절 */}
      <div className="absolute top-0 right-0 z-10">
        <span className="text-detail-s lg:text-detail-xs px-2.5 py-1 lg:px-1.5 lg:py-0.5 bg-white/25 text-white rounded-md lg:rounded font-bold lg:font-medium whitespace-nowrap backdrop-blur-md border border-white/20 shadow-sm">
          {address === "전북특별자치도" ? "기본위치" : "실시간 위치"}
        </span>
      </div>

      {/* 상단 섹션: 주소 및 온도 */}
      <div className="flex flex-col flex-1 justify-center pb-3 border-b border-white/10 mt-2 lg:mt-0">
        <div className="pr-20 lg:pr-16"> {/* 배지가 커졌으므로 겹치지 않게 여백 추가 */}
          <span className="text-white text-body-m-bold lg:text-body-l-bold truncate block leading-tight">
            {address || "위치 계산 중..."}
          </span>
          <div className="flex items-baseline gap-2 mt-2 lg:mt-1.5">
            <span className="text-4xl lg:text-4xl font-light text-white leading-none tracking-tighter">
              {Math.round(weather.main.temp)}°
            </span>
            <span className="text-body-s lg:text-body-s text-white/80 font-medium">
              {weather.weather[0].description}
            </span>
          </div>
        </div>
      </div>

      {/* 하단 섹션: 상세 정보 그리드 */}
      <div className="grid grid-cols-2 gap-x-4 lg:gap-x-8 gap-y-2.5 lg:gap-y-2.5 pt-4 lg:pt-3">
        {details.map((item, idx) => (
          <div key={idx} className="flex justify-between items-center group">
            <span className="text-detail-m lg:text-detail-m text-white/60 font-medium">
              {item.label}
            </span>
            <span className="text-detail-m lg:text-detail-m font-bold text-white">
              {item.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WeatherBox;
import "./App.css";
import AllRoutes from "@/routes/Routes";


function App() {
  return <AllRoutes />;
}

export default App;
